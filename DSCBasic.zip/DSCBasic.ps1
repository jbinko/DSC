Configuration RunDSCBasic {
       Import-DscResource -ModuleName xSystemSecurity
       Node Localhost {
 
           WindowsFeature DscService {
               Name = "DSC-Service"
               Ensure = "Present"
           }
 
           xIEESc DscIE {
               UserRole = "Users"
               IsEnabled = $false
           }
      }
}
