Configuration RunDSCBasic {

	Import-DscResource -ModuleName xSystemSecurity
		
	Node Localhost {

		xIEESc DscIE1 {

			UserRole = "Users"
			IsEnabled = $false
		}
			
		xIEESc DscIE2 {
			
			UserRole = "Administrators"
			IsEnabled = $false
		}

		Registry RegistryKey1
		{
			Ensure = "Present"  # Console font 7x12
			Key = "HKEY_USERS\.DEFAULT\Console"
			ValueName = "Fontsize"
			ValueData = "786439"
		}

		Registry RegistryKey2
		{
			Ensure = "Present"  # Console InsertMode
			Key = "HKEY_USERS\.DEFAULT\Console"
			ValueName = "InsertMode"
			ValueData = "1"
		}

		Registry RegistryKey3
		{
			Ensure = "Present"  # Console QuickMode
			Key = "HKEY_USERS\.DEFAULT\Console"
			ValueName = "QuickEdit"
			ValueData = "1"
		}

		Registry RegistryKey4
		{
			Ensure = "Present"  # Disable hide file extension
			Key = "HKEY_USERS\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
			ValueName = "HideFileExt"
			ValueData = "0"
		}

		Registry RegistryKey5
		{
			Ensure = "Present"  # Optimize UI for best performance
			Key = "HKEY_USERS\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
			ValueName = "VisualFXSetting"
			ValueData = "2"
		}
			
		Service ServiceDisable1
		{
			Name = "SharedAccess"
			StartupType = "Disabled"
			State = "Stopped"
		}

		Service ServiceDisable2
		{
			Name = "Spooler"
			StartupType = "Disabled"
			State = "Stopped"
		}

		Service ServiceDisable3
		{
			Name = "TapiSrv"
			StartupType = "Disabled"
			State = "Stopped"
		}
	}
}
